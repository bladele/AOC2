//
//  ViewController.h
//  AOC2_WeekOne
//
//  Created by Bodunrin Ladele on 12/2/13.
//  Copyright (c) 2013 bladele. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CharacterFactory.h"

@interface ViewController : UIViewController
{
    UILabel *humanLabel;
    UILabel *humanLabelTwo;
    UILabel *elfLabel;
    UILabel *elfLabelTwo;
    UILabel *morlockLabel;
    UILabel *morlockLabelTwo;
    
}


@end
